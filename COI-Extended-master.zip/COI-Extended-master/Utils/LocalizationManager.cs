using System.Collections.Generic;

public static class LocalizationManager
{
    private static readonly Dictionary<string, string> RuTranslations = new()
    {
    // === Главные заголовки ===
    { "COI: Extended Debug Menu", "COI: Расширенное Отладочное Меню" },
    { "COI: Extended - Debug Menu", "COI: Расширенное - Отладочное Меню" },

    // === Разделы из COIDebugWindowView ===
    { "Finish All Exploration", "Завершить всю разведку" },
    { "Reveal All Locations", "Открыть все локации" },
    { "Generate New Map", "Создать новую карту" },
    { "Make New Map (Slow)", "Создать новую карту (медленно)" },
    { "This function will create a new map.  It can take a long time to do so!  Old contracts and quick trades will be duplicated in your list, this has no effect on gameplay.  New world map will take place of the old world map and new locations will be included.", 
      "Эта функция создаёт новую карту. Может занять много времени! Старые контракты и быстрые сделки дублируются, но это не влияет на игру. Новая карта заменит старую." },
    { "Reverse Game Over", "Отменить проигрыш" },
    { "Game Not Over", "Игра продолжается" },

    // === Новые строки из CargoDrydockWindowView ===
    { "SHIP CONSTRUCTION PROGRESS", "ПРОГРЕСС ПОСТРОЙКИ КОРАБЛЯ" },
    { "Deploy New Ship", "Запустить новый корабль" },
    { "INPUTS", "ВХОДНЫЕ РЕСУРСЫ" },
    { "None", "Нет" },

    // === Остальные примеры ===
    { "Instant Build", "Мгновенное строительство" },
    { "Free Research", "Бесплатные исследования" },
    { "No Construction Cost", "Бесплатное строительство" },
    { "Infinite Focus Points", "Бесконечные очки фокуса" },
    { "Unlimited Water Reserves", "Неограниченные запасы воды" },
    { "Fast Ore Sorting", "Быстрая сортировка руды" },
    { "Unlock Speeds Up to 15x", "Разблокировать скорость до 15x" },
    { "Enable Cheats", "Включить читы" },
    { "Disable Cheats", "Выключить читы" },
    { "Toggle Cheats", "Переключить читы" }
};

    public static string Translate(string key)
    {
        if (RuTranslations.TryGetValue(key, out var value))
            return value;
        
        // Если перевода нет — возвращаем оригинальный ключ
        return key;
    }
}